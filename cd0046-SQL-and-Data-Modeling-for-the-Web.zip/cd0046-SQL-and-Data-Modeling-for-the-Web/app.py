#----------------------------------------------------------------------------#
# Imports
#----------------------------------------------------------------------------#
from datetime import date
from enum import Enum
import sys
import dateutil.parser
import babel
from flask import Flask, render_template, request, Response, flash, redirect, url_for
from flask_moment import Moment
from flask_sqlalchemy import SQLAlchemy
import logging
from logging import Formatter, FileHandler
from flask_wtf import Form
from forms import *
from flask_migrate import Migrate
#----------------------------------------------------------------------------#
# App Config.
#----------------------------------------------------------------------------#

app = Flask(__name__)
moment = Moment(app)
app.config.from_object('config')
app.secret_key = 'Traore@50'
db = SQLAlchemy(app)

migrate = Migrate(app, db)

#----------------------------------------------------------------------------#
# Models.
#----------------------------------------------------------------------------#

class Venue(db.Model):
    __tablename__ = 'venues'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    city = db.Column(db.String(120), nullable=False)
    state = db.Column(db.String(120), nullable=False)
    address = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(120), nullable=False)
    genre = db.Column(db.String(120), nullable=False)
    facebook_link = db.Column(db.String(120), nullable=False)
    image_link = db.Column(db.String(500), nullable=False)
    website_link = db.Column(db.String(500), nullable=False)
    seeking_talent = db.Column(db.Boolean(), default=False, nullable=True)
    seeking_description = db.Column(db.String(700), nullable=False)

    def __repr__(self):
      return f'<Name: {self.name}, City: {self.city}, State: {self.address}, Address: {self.address}, Phone: {self.phone}, Image_link: {self.image_link}, Genres: {self.genre}, Facebook_link: {self.facebook_link}, Image_link: {self.image_link}, Website_link: {self.website_link}, Seekin_talent: {self.seeking_talent}, Seeking_description: {self.seeking_description}>'
          

class Artist(db.Model):
    __tablename__ = 'artists'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    city = db.Column(db.String(120), nullable=False)
    state = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(120), nullable=False)
    genre = db.Column(db.String(120), nullable=False)
    facebook_link = db.Column(db.String(120), nullable=False)
    image_link = db.Column(db.String(500), nullable=False)
    website_link = db.Column(db.String(500), nullable=False)
    venues = db.relationship(
      "Venue", secondary="shows", backref=db.backref("artists", lazy=True)
    )
    seeking_venue = db.Column(db.Boolean(), default=False, nullable=True)
    seeking_description = db.Column(db.String(700), nullable=False)

    def __repr__(self):
      return f'<Name: {self.name}, City: {self.city}, Phone: {self.phone}, Genres: {self.genre}, Facebook_link: {self.facebook_link}, Image_link: {self.image_link}, Website_link: {self.website_link}, Seekin_talent: {self.seeking_venue}, Seeking_description: {self.seeking_description}>'


class Show(db.Model):
    __tablename__ = 'shows'
    id = db.Column(db.Integer, primary_key=True)
    venue_id =  db.Column(db.Integer, db.ForeignKey('venues.id'))
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    artist_id =  db.Column(db.Integer, db.ForeignKey('artists.id'))
    
    def __repr__(self):
      return f"<Venue_id:{self.venue_id}, Artist_id: {self.artist_id}, Start_time: {self.start_time}, venue: {self.venue}, Artist:{self.artist}"
#-------------
# ---------------------------------------------------------------#
# Filters.
#----------------------------------------------------------------------------#
def format_datetime(value, format='medium'):
  if isinstance(value, str):
    date = dateutil.parser.parse(value)
  else:
    date = value
  if format == 'full':
      format="EEEE MMMM, d, y 'at' h:mma"
  elif format == 'medium':
      format="EE MM, dd, y h:mma"
  return babel.dates.format_datetime(date, format, locale='en')

app.jinja_env.filters['datetime'] = format_datetime

#----------------------------------------------------------------------------#
# Controllers.
#----------------------------------------------------------------------------#

@app.route('/')
def index():
  return render_template('pages/home.html')


#  Venue
#  ----------------------------------------------------------------

@app.route('/venue')
def venue():
  data = Venue.query.limit(10).all()
  return render_template('pages/venue.html', areas=data)

@app.route('/venue/search', methods=['POST'])
def search_venue():
  search_term = request.form.get("search_term", "")

  response = {
    "count": 0,
    "data": []
  }

  resultSearch = (
      db.session.query(Venue).filter(Venue.name.ilike(f"%{search_term}%")).all()
  )

  response['count'] = len(resultSearch)
  for result in resultSearch:
    item = {
      "id": result.id,
      "name": result.name,
    }
    response["data"].append(item)



  return render_template(
      "pages/search_venues.html",
      results=response,
      search_term=request.form.get("search_term", ""),
  )

@app.route('/venue/<int:venue_id>')
def show_venue(venue_id):
  # shows the venue page with the given venue_id
  form = VenueForm()
  venues = Venue.query.get(venue_id)
  artist = Artist.query.all()
  shows = Show.query.filter_by(venue_id=venue_id).all()

  for art in artist:
    artist_image = art.image_link
    artist_name = art.name
  past_shows = []
  upcoming_shows = []
  curent_time = datetime.utcnow()


  for show in shows:
    if show.artist_id == art.id:
      show_data = {
      "artist_id": show.artist_id,
      "venue_id": show.venue_id,
      "artist_image_link": artist_image,
      "artist_name": artist_name,
      "start_time": show.start_time
    }
  
      if curent_time > show.start_time:
        past_shows.append(show_data)

      else:
        upcoming_shows.append(show_data)

  data={
    "id": venues.id,
    "name": venues.name,
    "genres": venues.genre,
    "address": venues.address,
    "city": venues.city,
    "state": venues.state,
    "phone": venues.phone,
    "website": venues.website_link,
    "facebook_link": venues.facebook_link,
    "seeking_talent": venues.seeking_talent,
    "seeking_description": venues.seeking_description,
    "image_link": venues.image_link,
    "past_shows": past_shows,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
    "upcoming_shows": upcoming_shows,
    "past_shows_count": len(past_shows),
    "upcoming_shows_count": len(upcoming_shows),
  }
  
  return render_template('pages/show_venue.html', venue=data, form=form)

#  Create Venue
#  ----------------------------------------------------------------

@app.route('/venue/create', methods=['GET'])
def create_venue_form():
  form = VenueForm()
  return render_template('forms/new_venue.html', form=form)

@app.route('/venue/create', methods=['POST'])
def create_venue_submission():
  # insert form data as a new Venue record in the db, instead
  seekingTalent = False

  name = request.form.get('name')
  city = request.form.get('city')
  state =request.form.get('state')
  address = request.form.get('address')
  phone = request.form.get('phone') 
  genre = request.form.get('genres')
  facebook_link = request.form.get('facebook_link')
  image_link = request.form.get('image_link')
  website_link = request.form.get('website_link')
  seeking_talent = request.form.get('seeking_talent')
  seeking_description = request.form.get('seeking_description')

  if seeking_talent == 'y':
    seekingTalent = True
  
  venues = Venue(
    name=name,
    city=city,
    state=state,
    address=address,
    phone=phone,
    genre=genre,
    facebook_link=facebook_link,
    image_link=image_link,
    website_link=website_link,
    seeking_talent=seekingTalent,
    seeking_description=seeking_description
  )

  try:
    db.session.add(venues)
    db.session.commit()
    flash('Venue ' + request.form['name'] + ' was successfully listed!')
    db.session.close()
  
  except Exception as e:
    db.session.rollback()
    db.session.close()
    flash('Venue ' + request.form['name'] + ' can\'t be listed! ' + str(e))
  return render_template('pages/home.html')

@app.route('/venue/<venue_id>', methods=['POST'])
def delete_venue(venue_id):
  try:
    deleteVenue = Venue.query.filter(Venue.id == venue_id).delete()
    db.session.commit()
    flash('Venue ' + deleteVenue.name + ' was succesfully deleted')
  except Exception as e:
    flash(str(e))
    db.session.rollback()
    flash('Venue ' + deleteVenue.name + ' coul not be deleted')
  finally:
    db.session.close()
    return redirect(url_for('index'))

#  Artist
#  ----------------------------------------------------------------
@app.route('/artist')
def artist():
  data = Artist.query.limit(10).all()
  return render_template('pages/artist.html', artist=data)

@app.route('/artist/search', methods=['POST'])
def search_artist():
  search_term = request.form.get('search_term', '')
  search_artist = db.session.query(Artist).filter(Artist.name.ilike(f'%{search_term}%')).all()
  
  response={
    "count": 0,
    "data": []
  }

  response["count"] = len(search_artist)
  for artist in search_artist:
    item = {
      "id":artist.id,
      "name":artist.name,
    }
    response["data"].append(item)

  return render_template('pages/search_artists.html', results=response, search_term=request.form.get('search_term', ''))

@app.route('/artist/<int:artist_id>')
def show_artist(artist_id):
  form = ArtistForm()
  artist = Artist.query.get(artist_id)
  shows = Show.query.filter_by(venue_id=artist_id).all()
  venues = Venue.query.all()
  
  past_shows = []
  upcoming_shows = []
  curent_time = datetime.utcnow()
  for show in shows:
    venue_data = {
      "venue_image_link":'',
      "venue_name": ''
    }
    for venu in venues:
      if venu.id == show.venue_id:
        venue_data["venue_image_link"] = venu.image_link
        venue_data["venue_name"] = venu.name
  

    show_data = {
      "artist_id": show.artist_id,
      "venue_id": show.venue_id,
      "venue_image_link": venue_data["venue_image_link"],
      "venue_name": venue_data["venue_name"],
      "start_time": show.start_time
    }

    
    if curent_time > show.start_time:
      past_shows.append(show_data)

    else:
      upcoming_shows.append(show_data)
  
  data={
    "id":artist.id,
    "name": artist.name,
    "genres": artist.genre,
    "city": artist.city,
    "state": artist.state,
    "phone": artist.phone,
    "website": artist.website_link,
    "facebook_link": artist.facebook_link,
    "seeking_venue": artist.seeking_venue,
    "seeking_description": artist.seeking_description,
    "image_link": artist.image_link,
    "past_shows": past_shows,
    "upcoming_shows": upcoming_shows,
    "past_shows_count": len(past_shows),
    "upcoming_shows_count": len(upcoming_shows),
  }

  return render_template('pages/show_artist.html', artist=data, form=form)

#  Update
#  ----------------------------------------------------------------
@app.route('/artist/<int:artist_id>/edit', methods=['GET'])
def edit_artist(artist_id):
  form = ArtistForm()
  artist = Artist.query.get(artist_id)

  all_artists={
    "id":artist.id,
    "name": artist.name,
    "genre": artist.genre,
    "city": artist.city,
    "state": artist.state,
    "phone": artist.phone,
    "website":artist.website_link,
    "facebook_link": artist.facebook_link,
    "seeking_venue": artist.seeking_venue,
    "seeking_description": artist.seeking_description,
    "image_link": artist.image_link
  }
  return render_template('forms/edit_artist.html', form=form, artist=all_artists)

@app.route('/artist/<int:artist_id>/edit', methods=['POST'])
def edit_artist_submission(artist_id):
  artist = Artist.query.get(artist_id)

  seeking_venue = False

  name = request.form.get("name")
  city = request.form.get("city")
  state = request.form.get("state")
  phone = request.form.get("phone")
  genres = request.form.getlist("genres")
  facebook_link = request.form.get("facebook_link")
  image_link = request.form.get("image_link")
  website_link = request.form.get("website_link")
  seeking_venue = request.form.get("seeking_venue")
  seeking_description = request.form.get("seeking_description")

  if seeking_venue == 'y':
    seeking_venue =True

  artist.name = name 
  artist.city = city 
  artist.state = state
  artist.phone = phone
  artist.genre = genres
  artist.facebook_link = facebook_link
  artist.image_link = image_link
  artist.websit_link = website_link
  artist.seeking_venue = seeking_venue
  artist.seeking_description = seeking_description

  try:
    db.session.add(artist)
    db.session.commit()
    flash('Artist ' + request.form['name'] + ' was succefully updated')
    db.session.close()
  except Exception as e:
    flash(str(e))
    db.session.rollback()
    db.session.close()
    flash('Artist ' + request.form['name'] + ' Could not be updated')
  return  redirect(url_for('show_artist', artist_id=artist_id))


@app.route('/venue/<int:venue_id>/edit', methods=['GET'])
def edit_venue(venue_id):
  form = VenueForm()
  venue_edit = Venue.query.get(venue_id)
  try:
    venue={
      "id": venue_edit.id,
      "name": venue_edit.name,
      "genres": venue_edit.genre,
      "address": venue_edit.address,
      "city": venue_edit.city ,
      "state": venue_edit.state,
      "phone": venue_edit.phone,
      "website": venue_edit.website_link,
      "facebook_link": venue_edit.facebook_link,
      "seeking_talent": venue_edit.seeking_talent,
      "seeking_description": venue_edit.seeking_description,
      "image_link": venue_edit.image_link
    }
  
  except:
    print(sys.exc_info)
  return render_template('forms/edit_venue.html', form=form, venue=venue)

@app.route('/venue/<int:venue_id>/edit', methods=['POST'])
def edit_venue_submission(venue_id):
  # Let's update a venue by retrieving its id.
  venue_edit_submit = Venue.query.get(venue_id)

  name = request.form.get("name")
  city = request.form.get("city")
  state = request.form.get("state")
  phone = request.form.get("phone")
  genres = request.form.get("genres")
  facebook_link = request.form.get("facebook_link")
  image_link = request.form.get("image_link")
  website_link = request.form.get("website_link")
  seeking_talent = request.form.get("seeking_venue")
  seeking_description = request.form.get("seeking_description")


  try:
    venue_edit_submit.name = name
    venue_edit_submit.city = city 
    venue_edit_submit.state = state
    venue_edit_submit.phone = phone
    venue_edit_submit.genre = genres
    venue_edit_submit.facebook_link = facebook_link
    venue_edit_submit.image_link = image_link
    venue_edit_submit.websit_link = website_link
    venue_edit_submit.seeking_talent = seeking_talent
    venue_edit_submit.seeking_description = seeking_description

    db.session.add(venue_edit_submit)
    db.session.commit()
    flash(f'Venue: {name} was succefully updated')
  except Exception as e:
    flash(str(e))
    db.session.rollback()
  return redirect(url_for('show_venue', venue_id=venue_id))

#  Create Artist
#  ----------------------------------------------------------------

@app.route('/artist/create', methods=['GET'])
def create_artist_form():
  form = ArtistForm()
  return render_template('forms/new_artist.html', form=form)

@app.route('/artist/create', methods=['POST'])
def create_artist_submission():
  # called upon submitting the new artist listing form
  seekingVenue = False

  name = request.form.get('name')
  city = request.form.get('city')
  state =request.form.get('state')
  phone = request.form.get('phone') 
  genres = request.form.get('genres')
  facebook_link = request.form.get('facebook_link')
  image_link = request.form.get('image_link')
  website_link = request.form.get('website_link')
  seeking_venue = request.form.get('seeking_venue')
  seeking_description = request.form.get('seeking_description')

  if seeking_venue == 'y':
    seekingVenue = True

  artist = Artist(
    name=name,
    city=city,
    state=state,
    phone=phone, 
    genre=genres,
    facebook_link=facebook_link,
    image_link=image_link,
    website_link=website_link,
    seeking_venue=seekingVenue,
    seeking_description=seeking_description
  )
  try:
    db.session.add(artist)
    db.session.commit()
    # On successful db insert, we will flash a message like bellow.
    flash('Artist ' + request.form['name'] + ' was successfully listed!')
    db.session.close()
    return redirect(url_for('index'))
  except Exception as e:
    # On unsuccessful db insert, we will flash an error instead.
    flash(str(e))
    db.session.rollback()
    flash('An error occurred. Artist ' + request.form['name'] + ' could not be listed.')
    db.session.close()
  return render_template('pages/home.html')


#  Shows
#  ----------------------------------------------------------------

@app.route('/shows')
def shows():
  # displays list of shows at /shows

  show_data = []
  try:
    list_show = Show.query.all()

    for show in list_show:
      venue_id = Venue.query.get(show.venue_id)
      artist_id = Artist.query.get(show.artist_id)

      item = {
        "venue_id": show.venue_id,
        "venue_name": venue_id.name,
        "artist_id": show.artist_id,
        "artist_name": artist_id.name,
        "artist_image_link": artist_id.image_link,
        "start_time": str(show.start_time)
      }
      show_data.append(item)

  except Exception as e:
    db.session.rollback()
    db.session.close()
    print(str(e))
    flash('There is an issue')
  
  return render_template("pages/shows.html", shows=show_data)


@app.route('/shows/<int:show_id>')
def show(show_id):
  form = ShowForm()
  shows = Show.query.get(show_id)

  for show in shows:
    show_data = []
  try:
      venue_id = Venue.query.get(show.venue_id)
      artist_id = Artist.query.get(show.artist_id)

      item = {
        "venue_id": show.venue_id,
        "venue_name": venue_id.name,
        "artist_id": show.artist_id,
        "artist_name": artist_id.name,
        "artist_image_link": artist_id.image_link,
        "start_time": str(show.start_time)
      }
      show_data.append(item)

  except Exception as e:
    db.session.rollback()
    db.session.close()
    print(str(e))
    flash('There is an issue')


  return render_template('pages/shows.html', data=show_data, form=form)


@app.route('/shows/create')
def create_shows():
  form = ShowForm()
  return render_template('forms/new_show.html', form=form)


@app.route('/shows/create', methods=['POST'])
def create_show_submission():
  # called to create new shows in the db, upon submitting new show listing form
  # From here we will insert form data as a new Show record in the db.
  form = ShowForm()
  if form.validate():
    errors = {"invalide_venue_id":False, "invalide_artist_id":False}
    try:
      venue_id = request.form.get('venue_id')
      artist_id = request.form.get('artist_id')
      start_time = request.form.get('start_time')

      # We will check that artist_id and venue_id entered by the user are not null.
      artistID = Artist.query.get(artist_id)
      if artistID is None:
        errors["invalide_artist_id"] = True
      
      venueID =Venue.query.get(venue_id)
      if venueID is None:
        errors["invalide_venue_id"] = True
      
      if artistID is not None and venueID is not None:

        show = Show(
          venue_id = venue_id,
          artist_id = artist_id,
          start_time = start_time
          )
        
        db.session.add(show)
        db.session.commit()
      # on successful db insert, flash success
        flash(f'Show whit artist name: {artistID.name} and venue name: {venueID.name} was successfully listed!')
        db.session.close()

    except Exception as e:
      flash(str(e))
      db.session.rollback()
      db.session.close()

      # on unsuccessful db insert, flash an error instead.
      flash('An error occurred. Show could not be listed.')
    finally:
      db.session.close()

    # If artist_id or venue_id entered by the user is none we will display one of the message below .
    if errors["invalide_artist_id"]:
      flash(f'There is no artist whit id: {request.form.get("artist_id")}')
    
    if errors["invalide_venue_id"]:
      flash(f'There is no venue whit id: {request.form.get("venue_id")}')
  else:
    flash(form.errors)
  return render_template('pages/home.html')

@app.errorhandler(404)
def not_found_error(error):
    return render_template('errors/404.html'), 404

@app.errorhandler(500)
def server_error(error):
    return render_template('errors/500.html'), 500


if not app.debug:
    file_handler = FileHandler('error.log')
    file_handler.setFormatter(
        Formatter('%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]')
    )
    app.logger.setLevel(logging.INFO)
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    app.logger.info('errors')

#----------------------------------------------------------------------------#
# Launch.
#----------------------------------------------------------------------------#

# Default port:
if __name__ == '__main__':
    app.run()

# Or specify port manually:
'''
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
'''
